To add a new type of game:
Duplicate one of the data assets in Assets/Resources/GameData and fill in rules values
